 #region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui.Chart;
#endregion

public enum Enum_PatternType
{
	PriceCongestion,
	DoubleTopDoubleBottom
}

// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
	
	public struct CorrPoints
	{
		public double point;
		public int barNumber;
		public bool vProc;
		public int bSincePlot;
	}

    /// <summary>
    /// Enter the description of your new custom indicator here
    /// </summary>
    [Description("Enter the description of your new custom indicator here")]
    public class DoubleDefined : Indicator
    {
                
		
		private Enum_PatternType iPatternType = Enum_PatternType.DoubleTopDoubleBottom;
		
		private int iStrength = 2;
        private int iNumBarsMax = 21; // Default setting for NumBarsMax
        private double iNumTicksMax = 0.0003; // Default setting for NumTicksMax
		private double iNumTicksVally = 0.0001;
		private int iNumPlotBarsMax = 21;
		
		private string  iSoundAlertUp	   = "alert2.wav";
		private string  iSoundAlertDown	   = "alert2.wav";	
		
		private bool iUseAudioAlert = false;
		private bool iUseChartMarker = true;
		
        private DataSeries sPivotL;
        private DataSeries sPivotU;	
		
        private DataSeries sHigh;
        private DataSeries sLow;	
		
		private CorrPoints[] uCorr;
		private CorrPoints[] lCorr;		
		
		private double vLowPoint;
		private double vHighPoint;
		                
        /// <summary>
        /// This method is used to configure the indicator and is called once before any bar data is loaded.
        /// </summary>
        protected override void Initialize()
        {
            Add(new Plot(new Pen(Color.FromKnownColor(KnownColor.DarkGray), 2), PlotStyle.Hash, "HPT"));
            Add(new Plot(new Pen(Color.FromKnownColor(KnownColor.DarkGray), 2), PlotStyle.Hash, "LPT"));
			
            CalculateOnBarClose	= true;
            Overlay				= true;
            PriceTypeSupported	= false;
			
			uCorr = new CorrPoints[2];
			lCorr = new CorrPoints[2];

			sLow = new DataSeries(this);
			sHigh = new DataSeries(this);
			
			sPivotL = new DataSeries(this);
			sPivotU = new DataSeries(this);
        }

        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {
			if(CurrentBar < iStrength * 2)
				return;
			
			switch(iPatternType)
			{
				case Enum_PatternType.DoubleTopDoubleBottom:
					
					//#region doubleTopDoubleBottom
					
					//Swings
					sPivotU.Set(Swing(iStrength).SwingHigh[0]);
					sPivotL.Set(Swing(iStrength).SwingLow[0]);
					
					
					//New High Point
					if(
						sPivotU[0] != sPivotU[1]
					  )
					{						
						uCorr[0].barNumber = CurrentBar;
						uCorr[0].point = sPivotU[0];				
						uCorr[0].vProc = false;
						uCorr[0].bSincePlot = -1;											
					}
					else
					{
						//Not Processed yet
						if(!uCorr[0].vProc && Math.Abs(CurrentBar - uCorr[0].barNumber) <= iNumPlotBarsMax) 
						{
							
							//Quick Double High
							if(
								High[iStrength - 1] < uCorr[0].point - iNumTicksVally && Math.Abs(High[0] - uCorr[0].point) <= iNumTicksMax
							  )
							{
								uCorr[0].vProc = true;
								
								//# bars since plot
								uCorr[0].bSincePlot = iStrength + 1;
								
								vHighPoint = High[HighestBar(High, CurrentBar - uCorr[0].barNumber)]; //uCorr[0].point;
								
								//HPT.Set(vHighPoint);
								for(int i = 1 ; i <= (CurrentBar - uCorr[0].barNumber) + (2*iStrength) - iStrength ; i++)
									HPT.Set(i, vHighPoint);
								
								//DrawDot(CurrentBar.ToString() + "t", true, 0, uCorr[0].point + .20, Color.Green);
							}		
						}
					}
					//***************
					//Continue Plots
					if(uCorr[0].bSincePlot != -1 && uCorr[0].bSincePlot <= iNumPlotBarsMax)
					{
						uCorr[0].bSincePlot++;
						HPT.Set(vHighPoint);
						
						//Pierced
						if(High[0] > vHighPoint)
						{
							//Stop Plot
							uCorr[0].bSincePlot = iNumPlotBarsMax + 1;							
						}
					}
					
					
					
					//***************//***************//***************//***************//***************//***************
					//											New Low Point
					//***************//***************//***************//***************//***************//***************
					if(sPivotL[0] != sPivotL[1])
					{						
						lCorr[0].barNumber = CurrentBar;
						lCorr[0].point = sPivotL[0];				
						lCorr[0].vProc = false;
						lCorr[0].bSincePlot = -1;											
					}
					else
					{
							//Quick Double Low
							if(
								Low[iStrength - 1] > lCorr[0].point + iNumTicksVally && Math.Abs(Low[0] - lCorr[0].point) <= iNumTicksMax
							  )
							{
								lCorr[0].vProc = true;
								
								//# bars since plot
								lCorr[0].bSincePlot = iStrength + 1;
								
								vLowPoint = Low[LowestBar(Low, CurrentBar - lCorr[0].barNumber)]; //lCorr[0].point;
								
								//HPT.Set(vHighPoint);
								for(int i = 1 ; i <= (CurrentBar - lCorr[0].barNumber) + (2*iStrength) - iStrength ; i++)
									LPT.Set(i, vLowPoint);
								
								//DrawDot(CurrentBar.ToString() + "tt", true, 0, lCorr[0].point - .20, Color.Red);
							}							
					}
					
					//***************
					//Continue Plots
					if(lCorr[0].bSincePlot != -1 && lCorr[0].bSincePlot <= iNumPlotBarsMax)
					{
						lCorr[0].bSincePlot++;
						LPT.Set(vLowPoint);
						
						//Pierced
						if(Low[0] < vLowPoint)
						{
							//Stop Plot
							lCorr[0].bSincePlot = iNumPlotBarsMax + 1;							
						}
					}	
					
				//#endregion;					
				break;
					
				case Enum_PatternType.PriceCongestion:
					#region PriceCongestion
					bool cHighs = true;
					bool cLows = true;
					
					sLow.Set(0);
					sHigh.Set(0);
					
					for(int i = 0 ; i < iNumBarsMax ; i++)
					{
						for(int j = 0 ; j < iNumBarsMax ; j++)
						{
							if(Math.Abs(High[j] - High[i]) > iNumTicksMax)
								cHighs = false;
							if(Math.Abs(Low[j] - Low[i]) > iNumTicksMax)
								cLows = false;							
						}
					}
					
					if(cHighs)
					{
						sHigh.Set(High[HighestBar(High, iNumBarsMax)]);
						
						for(int k = 0 ; k < iNumBarsMax ; k++)
						{
							HPT.Set(k, sHigh[0]);
						}
					}
					
					if(cLows)
					{
						sLow.Set(Low[LowestBar(Low, iNumBarsMax)]);
						
						for(int k = 0 ; k < iNumBarsMax ; k++)
						{
							LPT.Set(k, sLow[0]);
						}
					}							
					
					//**************
					// BREAK UP
					//**************
					if(High[0] > sHigh[1] && sHigh[1] != 0)
					{
						if(iUseChartMarker)
						{
							DrawArrowUp(CurrentBar.ToString(), true, 0,  High[0] + TickSize * 2, Color.Cyan);					
						}
						if(iUseAudioAlert && !Historical)
						{
							PlaySound(iSoundAlertUp);
						}
					}
					
					//**************
					// BREAK DOWN
					//**************
					if(Low[0] < sLow[1] && sLow[1] != 0)
					{
						if(iUseChartMarker)
						{
							DrawArrowDown(CurrentBar.ToString(), true, 0, Low[0] - TickSize * 2, Color.Magenta);					
						}
						if(iUseAudioAlert && !Historical)
						{
							PlaySound(iSoundAlertDown);
						}
					}
					#endregion					
				break;
			}
				
															
			
        } //end ONBARUPDATE

        #region Properties

        [Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove		
        public DataSeries HPT
        {
            get { return Values[0]; }
        }
        [Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove		
        public DataSeries LPT
        {
            get { return Values[1]; }
        }		
		
		
        [Description("")]
        [Category("Parameters")]
        public int Strength
        {
            get { return iStrength; }
            set { iStrength = Math.Max(1, value); }
        }		
        [Description("")]
        [Category("Parameters")]
        public int NumBarsMax
        {
            get { return iNumBarsMax; }
            set { iNumBarsMax = Math.Max(1, value); }
        }
        [Description("")]
        [Category("Parameters")]
        public double NumTicksMax
        {
            get { return iNumTicksMax; }
            set { iNumTicksMax = Math.Max(0, value); }
        }		
        [Description("")]
        [Category("Parameters")]
        public double NumTicksVally
        {
            get { return iNumTicksVally; }
            set { iNumTicksVally = Math.Max(0, value); }
        }						
        [Description("")]
        [Category("Parameters")]
        public int NumPlotBarsMax
        {
            get { return iNumPlotBarsMax; }
            set { iNumPlotBarsMax = Math.Max(1, value); }
        }	
		
        [Description("")]
        [Category("Parameters")]
        public bool UseAudioAlert
        {
            get { return iUseAudioAlert; }
            set { iUseAudioAlert = value; }
        }	
        [Description("")]
        [Category("Parameters")]
        public bool UseChartMarker
        {
            get { return iUseChartMarker; }
            set { iUseChartMarker = value; }
        }		

        [Description("")]
        [Category("Parameters")]
        public string SoundAlertUp
        {
            get { return iSoundAlertUp; }
            set { iSoundAlertUp = value; }
        }				
        [Description("")]
        [Category("Parameters")]
        public string SoundAlertDown
        {
            get { return iSoundAlertDown; }
            set { iSoundAlertDown = value; }
        }	
		[Description("Pattern Type")]
        [Category("Parameters")]
        public Enum_PatternType PatternType
        {
            get { return iPatternType; }
            set { iPatternType = value; }
        }							
        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.
// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    public partial class Indicator : IndicatorBase
    {
        private DoubleDefined[] cacheDoubleDefined = null;

        private static DoubleDefined checkDoubleDefined = new DoubleDefined();

        /// <summary>
        /// Enter the description of your new custom indicator here
        /// </summary>
        /// <returns></returns>
        public DoubleDefined DoubleDefined(int numBarsMax, int numPlotBarsMax, double numTicksMax, double numTicksVally, Enum_PatternType patternType, string soundAlertDown, string soundAlertUp, int strength, bool useAudioAlert, bool useChartMarker)
        {
            return DoubleDefined(Input, numBarsMax, numPlotBarsMax, numTicksMax, numTicksVally, patternType, soundAlertDown, soundAlertUp, strength, useAudioAlert, useChartMarker);
        }

        /// <summary>
        /// Enter the description of your new custom indicator here
        /// </summary>
        /// <returns></returns>
        public DoubleDefined DoubleDefined(Data.IDataSeries input, int numBarsMax, int numPlotBarsMax, double numTicksMax, double numTicksVally, Enum_PatternType patternType, string soundAlertDown, string soundAlertUp, int strength, bool useAudioAlert, bool useChartMarker)
        {
            checkDoubleDefined.NumBarsMax = numBarsMax;
            numBarsMax = checkDoubleDefined.NumBarsMax;
            checkDoubleDefined.NumPlotBarsMax = numPlotBarsMax;
            numPlotBarsMax = checkDoubleDefined.NumPlotBarsMax;
            checkDoubleDefined.NumTicksMax = numTicksMax;
            numTicksMax = checkDoubleDefined.NumTicksMax;
            checkDoubleDefined.NumTicksVally = numTicksVally;
            numTicksVally = checkDoubleDefined.NumTicksVally;
            checkDoubleDefined.PatternType = patternType;
            patternType = checkDoubleDefined.PatternType;
            checkDoubleDefined.SoundAlertDown = soundAlertDown;
            soundAlertDown = checkDoubleDefined.SoundAlertDown;
            checkDoubleDefined.SoundAlertUp = soundAlertUp;
            soundAlertUp = checkDoubleDefined.SoundAlertUp;
            checkDoubleDefined.Strength = strength;
            strength = checkDoubleDefined.Strength;
            checkDoubleDefined.UseAudioAlert = useAudioAlert;
            useAudioAlert = checkDoubleDefined.UseAudioAlert;
            checkDoubleDefined.UseChartMarker = useChartMarker;
            useChartMarker = checkDoubleDefined.UseChartMarker;

            if (cacheDoubleDefined != null)
                for (int idx = 0; idx < cacheDoubleDefined.Length; idx++)
                    if (cacheDoubleDefined[idx].NumBarsMax == numBarsMax && cacheDoubleDefined[idx].NumPlotBarsMax == numPlotBarsMax && Math.Abs(cacheDoubleDefined[idx].NumTicksMax - numTicksMax) <= double.Epsilon && Math.Abs(cacheDoubleDefined[idx].NumTicksVally - numTicksVally) <= double.Epsilon && cacheDoubleDefined[idx].PatternType == patternType && cacheDoubleDefined[idx].SoundAlertDown == soundAlertDown && cacheDoubleDefined[idx].SoundAlertUp == soundAlertUp && cacheDoubleDefined[idx].Strength == strength && cacheDoubleDefined[idx].UseAudioAlert == useAudioAlert && cacheDoubleDefined[idx].UseChartMarker == useChartMarker && cacheDoubleDefined[idx].EqualsInput(input))
                        return cacheDoubleDefined[idx];

            DoubleDefined indicator = new DoubleDefined();
            indicator.BarsRequired = BarsRequired;
            indicator.CalculateOnBarClose = CalculateOnBarClose;
            indicator.Input = input;
            indicator.NumBarsMax = numBarsMax;
            indicator.NumPlotBarsMax = numPlotBarsMax;
            indicator.NumTicksMax = numTicksMax;
            indicator.NumTicksVally = numTicksVally;
            indicator.PatternType = patternType;
            indicator.SoundAlertDown = soundAlertDown;
            indicator.SoundAlertUp = soundAlertUp;
            indicator.Strength = strength;
            indicator.UseAudioAlert = useAudioAlert;
            indicator.UseChartMarker = useChartMarker;
            indicator.SetUp();

            DoubleDefined[] tmp = new DoubleDefined[cacheDoubleDefined == null ? 1 : cacheDoubleDefined.Length + 1];
            if (cacheDoubleDefined != null)
                cacheDoubleDefined.CopyTo(tmp, 0);
            tmp[tmp.Length - 1] = indicator;
            cacheDoubleDefined = tmp;
            Indicators.Add(indicator);

            return indicator;
        }

    }
}

// This namespace holds all market analyzer column definitions and is required. Do not change it.
namespace NinjaTrader.MarketAnalyzer
{
    public partial class Column : ColumnBase
    {
        /// <summary>
        /// Enter the description of your new custom indicator here
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.DoubleDefined DoubleDefined(int numBarsMax, int numPlotBarsMax, double numTicksMax, double numTicksVally, Enum_PatternType patternType, string soundAlertDown, string soundAlertUp, int strength, bool useAudioAlert, bool useChartMarker)
        {
            return _indicator.DoubleDefined(Input, numBarsMax, numPlotBarsMax, numTicksMax, numTicksVally, patternType, soundAlertDown, soundAlertUp, strength, useAudioAlert, useChartMarker);
        }

        /// <summary>
        /// Enter the description of your new custom indicator here
        /// </summary>
        /// <returns></returns>
        public Indicator.DoubleDefined DoubleDefined(Data.IDataSeries input, int numBarsMax, int numPlotBarsMax, double numTicksMax, double numTicksVally, Enum_PatternType patternType, string soundAlertDown, string soundAlertUp, int strength, bool useAudioAlert, bool useChartMarker)
        {
            return _indicator.DoubleDefined(input, numBarsMax, numPlotBarsMax, numTicksMax, numTicksVally, patternType, soundAlertDown, soundAlertUp, strength, useAudioAlert, useChartMarker);
        }

    }
}

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    public partial class Strategy : StrategyBase
    {
        /// <summary>
        /// Enter the description of your new custom indicator here
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.DoubleDefined DoubleDefined(int numBarsMax, int numPlotBarsMax, double numTicksMax, double numTicksVally, Enum_PatternType patternType, string soundAlertDown, string soundAlertUp, int strength, bool useAudioAlert, bool useChartMarker)
        {
            return _indicator.DoubleDefined(Input, numBarsMax, numPlotBarsMax, numTicksMax, numTicksVally, patternType, soundAlertDown, soundAlertUp, strength, useAudioAlert, useChartMarker);
        }

        /// <summary>
        /// Enter the description of your new custom indicator here
        /// </summary>
        /// <returns></returns>
        public Indicator.DoubleDefined DoubleDefined(Data.IDataSeries input, int numBarsMax, int numPlotBarsMax, double numTicksMax, double numTicksVally, Enum_PatternType patternType, string soundAlertDown, string soundAlertUp, int strength, bool useAudioAlert, bool useChartMarker)
        {
            if (InInitialize && input == null)
                throw new ArgumentException("You only can access an indicator with the default input/bar series from within the 'Initialize()' method");

            return _indicator.DoubleDefined(input, numBarsMax, numPlotBarsMax, numTicksMax, numTicksVally, patternType, soundAlertDown, soundAlertUp, strength, useAudioAlert, useChartMarker);
        }

    }
}
#endregion
